
CREATE TABLE authentification (
  id       SERIAL UNIQUE NOT NULL,
  login    VARCHAR(30) PRIMARY KEY,
  password VARCHAR(100)  NOT NULL,
  admin    BOOLEAN DEFAULT FALSE
);

-- user / password
INSERT INTO authentification (login, password, admin)
VALUES ('user', '$2y$13$GsKNULnaiItvrKXD7B2/SOICAJdNeLaxhTBhsFTHXI3tHJOIzwV06', FALSE);
INSERT INTO authentification (login, password, admin)
VALUES ('admin', '$2y$13$xoGvFuGrh8rKyYmgekcM.uS3cswiE9o16aQDTwzPqi7gMzp1Bf9h2', TRUE);
