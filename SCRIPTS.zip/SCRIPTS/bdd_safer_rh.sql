--Personnes

CREATE TABLE situation_familiale (
  id_situation_familiale       SERIAL      NOT NULL,
  intitule_situation_familiale VARCHAR(50) NOT NULL,
  PRIMARY KEY (id_situation_familiale)
);


CREATE TABLE nature_contrat (
  id_nature_contrat       SERIAL      NOT NULL,
  intitule_nature_contrat VARCHAR(50) NOT NULL,
  PRIMARY KEY (id_nature_contrat)
);


CREATE TABLE type_entree_contrat (
  id_type_entree_contrat       SERIAL      NOT NULL,
  intitule_type_entree_contrat VARCHAR(50) NOT NULL,
  PRIMARY KEY (id_type_entree_contrat)
);


CREATE TABLE etablissement (
  id_etablissement       SERIAL      NOT NULL,
  intitule_etablissement VARCHAR(50) NOT NULL,
  adresse_etablissement  VARCHAR(300),
  PRIMARY KEY (id_etablissement)
);


CREATE TABLE departement (
  numero_departement   VARCHAR(3)  NOT NULL,
  intitule_departement VARCHAR(50) NOT NULL,
  PRIMARY KEY (numero_departement)
);


CREATE TABLE departement_poste (
  id_departement_poste       SERIAL      NOT NULL,
  intitule_departement_poste VARCHAR(50) NOT NULL,
  PRIMARY KEY (id_departement_poste)
);


CREATE TABLE pays (
  code_pays     VARCHAR(3)  NOT NULL,
  intitule_pays VARCHAR(50) NOT NULL,
  PRIMARY KEY (code_pays)
);


CREATE TABLE categorie_poste (
  id_categorie_poste       SERIAL      NOT NULL,
  intitule_categorie_poste VARCHAR(50) NOT NULL,
  PRIMARY KEY (id_categorie_poste)
);

--
CREATE TABLE categorie_sp (
  id_categorie_sp   SERIAL     NOT NULL,
  code_categorie_sp VARCHAR(5) NOT NULL,
  PRIMARY KEY (id_categorie_sp)
);

--
CREATE TABLE niveau (
  id_niveau        SERIAL      NOT NULL,
  code_niveau      VARCHAR(50) NOT NULL,
  min_remuneration INT         NOT NULL,
  max_remuneration INT         NOT NULL,
  PRIMARY KEY (id_niveau)
);

--
CREATE TABLE emploi_ccn (
  id_emploi_ccn       SERIAL                                        NOT NULL,
  intitule_emploi_ccn VARCHAR(50)                                   NOT NULL,
  id_categoriesp      INT REFERENCES categorie_sp (id_categorie_sp) NOT NULL,
  id_niveau           INT REFERENCES niveau (id_niveau)             NOT NULL,
  mission             VARCHAR(5000) DEFAULT '',
  PRIMARY KEY (id_emploi_ccn)
);


CREATE TABLE indice (
  id_indice     INT     NOT NULL,
  valeur_indice DECIMAL NOT NULL,
  PRIMARY KEY (id_indice)
);


CREATE TABLE convention (
  id_convention       SERIAL      NOT NULL,
  intitule_convention VARCHAR(50) NOT NULL,
  PRIMARY KEY (id_convention)
);


CREATE TABLE bulletin_modele_salaire (
  id_bulletin_modele_salaire       SERIAL      NOT NULL,
  intitule_bulletin_modele_salaire VARCHAR(50) NOT NULL,
  PRIMARY KEY (id_bulletin_modele_salaire)
);

CREATE TABLE modalite_exercice_travail (
  id_modalite_exercice_travail       SERIAL      NOT NULL,
  intitule_modalite_exercice_travail VARCHAR(50) NOT NULL,
  PRIMARY KEY (id_modalite_exercice_travail)
);

CREATE TABLE etat_civil (
  id_collaborateur       SERIAL  NOT NULL,
  civilite               INTEGER,
  nom                    VARCHAR(50),
  prenom                 VARCHAR(50),
  nom_jeune_fille        VARCHAR(50),
  id_situation_familiale INT REFERENCES situation_familiale (id_situation_familiale),
  nb_enfants             INT,
  est_complet            BOOLEAN NOT NULL,
  PRIMARY KEY (id_collaborateur)
);


CREATE TABLE immatriculation (
  id_collaborateur             INT REFERENCES etat_civil (id_collaborateur) NOT NULL,
  date_naissance               DATE,
  numero_departement_naissance VARCHAR(3) REFERENCES departement (numero_departement),
  code_pays_naissance          VARCHAR(3) REFERENCES pays (code_pays),
  commune_naissance            VARCHAR(50),
  code_commune_naissance       INT,
  nationalite                  VARCHAR(50),
  numero_immatriculation       VARCHAR(22),
  email                        VARCHAR(50),
  PRIMARY KEY (id_collaborateur)
);


CREATE TABLE coordonnees (
  id_collaborateur   INT REFERENCES etat_civil (id_collaborateur) NOT NULL,
  adresse            VARCHAR(100),
  complement_adresse VARCHAR(50),
  code_postal        INT,
  commune            VARCHAR(50),
  code_pays          VARCHAR(3) REFERENCES pays (code_pays),
  iban               VARCHAR(34),
  bic                VARCHAR(11),
  PRIMARY KEY (id_collaborateur)
);


CREATE TABLE contrat (
  id_collaborateur       INT REFERENCES etat_civil (id_collaborateur),
  id_naturecontrat       INT REFERENCES nature_contrat (id_nature_contrat),
  date_debut             DATE,
  fin_periode_essai      DATE,
  id_type_entree_contrat INT REFERENCES type_entree_contrat (id_type_entree_contrat),
  id_etablissement       INT REFERENCES etablissement (id_etablissement),
  PRIMARY KEY (id_collaborateur)
);


CREATE TABLE poste (
  id_collaborateur     INT REFERENCES etat_civil (id_collaborateur) NOT NULL,
  id_departement_poste INT REFERENCES departement_poste (id_departement_poste),
  id_categorie_poste   INT REFERENCES categorie_poste (id_categorie_poste),
  PRIMARY KEY (id_collaborateur)
);

--
CREATE TABLE emploi (
  id_collaborateur INT REFERENCES etat_civil (id_collaborateur) NOT NULL,
  id_emploi_ccn    INT REFERENCES emploi_ccn (id_emploi_ccn),
  id_indice        INT REFERENCES indice (id_indice),
  coefficient      INT,
  PRIMARY KEY (id_collaborateur)
);


CREATE TABLE statut (
  id_collaborateur INT REFERENCES etat_civil (id_collaborateur) NOT NULL,
  id_convention    INT REFERENCES convention (id_convention),
  est_agirc        BOOLEAN,
  PRIMARY KEY (id_collaborateur)
);


CREATE TABLE salaire (
  id_collaborateur           INT REFERENCES etat_civil (id_collaborateur) NOT NULL,
  id_bulletin_modele_salaire INT REFERENCES bulletin_modele_salaire (id_bulletin_modele_salaire),
  PRIMARY KEY (id_collaborateur)
);


CREATE TABLE horaire (
  id_collaborateur             INT REFERENCES etat_civil (id_collaborateur) NOT NULL,
  nb_heures_travaillees        DOUBLE PRECISION,
  id_modalite_exercice_travail INT REFERENCES modalite_exercice_travail (id_modalite_exercice_travail),
  PRIMARY KEY (id_collaborateur)
);


CREATE TABLE administratif (
  id_collaborateur          INT REFERENCES etat_civil (id_collaborateur) NOT NULL,
  nom_personne_a_prevenir_1 VARCHAR(50),
  tel_personne_a_prevenir_1 VARCHAR(19),
  nom_personne_a_prevenir_2 VARCHAR(50),
  tel_personne_a_prevenir_2 VARCHAR(19),
  PRIMARY KEY (id_collaborateur)
);

--Documents

CREATE TABLE contrat_travail (
  indice          INT           NOT NULL,
  est_obligatoire BOOLEAN       NOT NULL,
  est_article     BOOLEAN       NOT NULL,
  titre_affiche   BOOLEAN       NOT NULL DEFAULT TRUE,
  intitule        VARCHAR(50)            DEFAULT 'Paragraphe',
  contenu         VARCHAR(5000) NOT NULL,
  PRIMARY KEY (indice)
);
CREATE TABLE lettre_embauche (
  indice          INT           NOT NULL,
  est_obligatoire BOOLEAN       NOT NULL,
  intitule        VARCHAR(50) DEFAULT 'Paragraphe',
  contenu         VARCHAR(5000) NOT NULL,
  PRIMARY KEY (indice)
);

--Insertions

INSERT INTO situation_familiale (intitule_situation_familiale) VALUES ('Célibataire');
INSERT INTO situation_familiale (intitule_situation_familiale) VALUES ('Marié(e)');
INSERT INTO situation_familiale (intitule_situation_familiale) VALUES ('Pacsé(e)');


INSERT INTO nature_contrat (intitule_nature_contrat) VALUES ('CDI');
INSERT INTO nature_contrat (intitule_nature_contrat) VALUES ('CDD');
INSERT INTO nature_contrat (intitule_nature_contrat) VALUES ('Mandat');


INSERT INTO type_entree_contrat (intitule_type_entree_contrat) VALUES ('Embauche');
INSERT INTO type_entree_contrat (intitule_type_entree_contrat) VALUES ('Mutation');
INSERT INTO type_entree_contrat (intitule_type_entree_contrat) VALUES ('Début de Mandat');


INSERT INTO etablissement (intitule_etablissement) VALUES ('Bordeaux');
INSERT INTO etablissement (intitule_etablissement) VALUES ('Limoges');
INSERT INTO etablissement (intitule_etablissement) VALUES ('Poitier');


INSERT INTO departement VALUES ('01', 'Ain');
INSERT INTO departement VALUES ('02', 'Aisne');
INSERT INTO departement VALUES ('03', 'Allier');
INSERT INTO departement VALUES ('04', 'Alpes-de-Haute-Provence');
INSERT INTO departement VALUES ('05', 'Hautes-Alpes');
INSERT INTO departement VALUES ('06', 'Alpes-Maritimes');
INSERT INTO departement VALUES ('07', 'Ardèche');
INSERT INTO departement VALUES ('08', 'Ardennes');
INSERT INTO departement VALUES ('09', 'Ariège');
INSERT INTO departement VALUES ('10', 'Aube');
INSERT INTO departement VALUES ('11', 'Aude');
INSERT INTO departement VALUES ('12', 'Aveyron');
INSERT INTO departement VALUES ('13', 'Bouches-du-Rhône');
INSERT INTO departement VALUES ('14', 'Calvados');
INSERT INTO departement VALUES ('15', 'Cantal');
INSERT INTO departement VALUES ('16', 'Charente');
INSERT INTO departement VALUES ('17', 'Charente-Maritime');
INSERT INTO departement VALUES ('18', 'Cher');
INSERT INTO departement VALUES ('19', 'Corrèze');
INSERT INTO departement VALUES ('2A', 'Corse-du-Sud');
INSERT INTO departement VALUES ('2B', 'Haute-Corse');
INSERT INTO departement VALUES ('21', 'Côte-d''Or');
INSERT INTO departement VALUES ('22', 'Côtes-d''Armor');
INSERT INTO departement VALUES ('23', 'Creuse');
INSERT INTO departement VALUES ('24', 'Dordogne');
INSERT INTO departement VALUES ('25', 'Doubs');
INSERT INTO departement VALUES ('26', 'Drôme');
INSERT INTO departement VALUES ('27', 'Eure');
INSERT INTO departement VALUES ('28', 'Eure-et-Loir');
INSERT INTO departement VALUES ('29', 'Finistère');
INSERT INTO departement VALUES ('30', 'Gard');
INSERT INTO departement VALUES ('31', 'Haute-Garonne');
INSERT INTO departement VALUES ('32', 'Gers');
INSERT INTO departement VALUES ('33', 'Gironde');
INSERT INTO departement VALUES ('34', 'Hérault');
INSERT INTO departement VALUES ('35', 'Ille-et-Vilaine');
INSERT INTO departement VALUES ('36', 'Indre');
INSERT INTO departement VALUES ('37', 'Indre-et-Loire');
INSERT INTO departement VALUES ('38', 'Isère');
INSERT INTO departement VALUES ('39', 'Jura');
INSERT INTO departement VALUES ('40', 'Landes');
INSERT INTO departement VALUES ('41', 'Loir-et-Cher');
INSERT INTO departement VALUES ('42', 'Loire');
INSERT INTO departement VALUES ('43', 'Haute-Loire');
INSERT INTO departement VALUES ('44', 'Loire-Atlantique');
INSERT INTO departement VALUES ('45', 'Loiret');
INSERT INTO departement VALUES ('46', 'Lot');
INSERT INTO departement VALUES ('47', 'Lot-et-Garonne');
INSERT INTO departement VALUES ('48', 'Lozère');
INSERT INTO departement VALUES ('49', 'Maine-et-Loire');
INSERT INTO departement VALUES ('50', 'Manche');
INSERT INTO departement VALUES ('51', 'Marne');
INSERT INTO departement VALUES ('52', 'Haute-Marne');
INSERT INTO departement VALUES ('53', 'Mayenne');
INSERT INTO departement VALUES ('54', 'Meurthe-et-Moselle');
INSERT INTO departement VALUES ('55', 'Meuse');
INSERT INTO departement VALUES ('56', 'Morbihan');
INSERT INTO departement VALUES ('57', 'Moselle');
INSERT INTO departement VALUES ('58', 'Nièvre');
INSERT INTO departement VALUES ('59', 'Nord');
INSERT INTO departement VALUES ('60', 'Oise');
INSERT INTO departement VALUES ('61', 'Orne');
INSERT INTO departement VALUES ('62', 'Pas-de-Calais');
INSERT INTO departement VALUES ('63', 'Puy-de-Dôme');
INSERT INTO departement VALUES ('64', 'Pyrénées-Atlantique');
INSERT INTO departement VALUES ('65', 'Hautes-Pyrénées');
INSERT INTO departement VALUES ('66', 'Pyrénées-Orientales');
INSERT INTO departement VALUES ('67', 'Bas-Rhin');
INSERT INTO departement VALUES ('68', 'Haut-Rhin');
INSERT INTO departement VALUES ('69', 'Rhône');
INSERT INTO departement VALUES ('70', 'Haute-Saône');
INSERT INTO departement VALUES ('71', 'Saône-et-Loire');
INSERT INTO departement VALUES ('72', 'Sarthe');
INSERT INTO departement VALUES ('73', 'Savoie');
INSERT INTO departement VALUES ('74', 'Haute-Savoie');
INSERT INTO departement VALUES ('75', 'Paris');
INSERT INTO departement VALUES ('76', 'Seine-Maritime');
INSERT INTO departement VALUES ('77', 'Seine-et-Marne');
INSERT INTO departement VALUES ('78', 'Yvelines');
INSERT INTO departement VALUES ('79', 'Deux-Sèvres');
INSERT INTO departement VALUES ('80', 'Somme');
INSERT INTO departement VALUES ('81', 'Tarn');
INSERT INTO departement VALUES ('82', 'Tarn-et-Garonne');
INSERT INTO departement VALUES ('83', 'Var');
INSERT INTO departement VALUES ('84', 'Vaucluse');
INSERT INTO departement VALUES ('85', 'Vendée');
INSERT INTO departement VALUES ('86', 'Vienne');
INSERT INTO departement VALUES ('87', 'Haute-Vienne');
INSERT INTO departement VALUES ('88', 'Vosges');
INSERT INTO departement VALUES ('89', 'Yonne');
INSERT INTO departement VALUES ('90', 'Territoire-de-Belfort');
INSERT INTO departement VALUES ('91', 'Essone');
INSERT INTO departement VALUES ('92', 'Hauts-de-Seine');
INSERT INTO departement VALUES ('93', 'Seine-Saint-Denis');
INSERT INTO departement VALUES ('94', 'Val-de-Marne');
INSERT INTO departement VALUES ('95', 'Val-d''Oise');
INSERT INTO departement VALUES ('971', 'Guadeloupe');
INSERT INTO departement VALUES ('972', 'Martinique');
INSERT INTO departement VALUES ('973', 'Guyane');
INSERT INTO departement VALUES ('974', 'La-Réunion');
INSERT INTO departement VALUES ('976', 'Mayotte');
INSERT INTO departement VALUES ('99', 'Etranger');


INSERT INTO departement_poste (intitule_departement_poste) VALUES ('Administratif');
INSERT INTO departement_poste (intitule_departement_poste) VALUES ('Foncier');
INSERT INTO departement_poste (intitule_departement_poste) VALUES ('Agent d''Entretien');


INSERT INTO pays VALUES ('FRA', 'France');
INSERT INTO pays VALUES ('AND', 'Andorre');
INSERT INTO pays VALUES ('BEL', 'Belgique');
INSERT INTO pays VALUES ('CAN', 'Canada');
INSERT INTO pays VALUES ('CHE', 'Suisse');
INSERT INTO pays VALUES ('CHN', 'Chine');
INSERT INTO pays VALUES ('DEU', 'Allemagne');
INSERT INTO pays VALUES ('ESP', 'Espagne');
INSERT INTO pays VALUES ('GBR', 'Grande-Bretagne');
INSERT INTO pays VALUES ('LUX', 'Luxembourg');
INSERT INTO pays VALUES ('USA', 'Etats-Unis d''Amérique');


INSERT INTO categorie_poste (intitule_categorie_poste) VALUES ('Agent d''Application');
INSERT INTO categorie_poste (intitule_categorie_poste) VALUES ('Cadre et Assimilés');
INSERT INTO categorie_poste (intitule_categorie_poste) VALUES ('Personnel d''Encadrement');
INSERT INTO categorie_poste (intitule_categorie_poste) VALUES ('Directeur Op. Foncières');


INSERT INTO niveau (code_niveau, min_remuneration, max_remuneration) VALUES ('I', 215, 300);
INSERT INTO niveau (code_niveau, min_remuneration, max_remuneration) VALUES ('II', 235, 330);
INSERT INTO niveau (code_niveau, min_remuneration, max_remuneration) VALUES ('III', 260, 390);
INSERT INTO niveau (code_niveau, min_remuneration, max_remuneration) VALUES ('IV', 290, 435);
INSERT INTO niveau (code_niveau, min_remuneration, max_remuneration) VALUES ('V', 305, 460);
INSERT INTO niveau (code_niveau, min_remuneration, max_remuneration) VALUES ('VI', 340, 510);
INSERT INTO niveau (code_niveau, min_remuneration, max_remuneration) VALUES ('VII', 380, 570);
INSERT INTO niveau (code_niveau, min_remuneration, max_remuneration) VALUES ('VIII', 400, 640);
INSERT INTO niveau (code_niveau, min_remuneration, max_remuneration) VALUES ('IX', 480, 770);
INSERT INTO niveau (code_niveau, min_remuneration, max_remuneration) VALUES ('X', 500, 800);
INSERT INTO niveau (code_niveau, min_remuneration, max_remuneration) VALUES ('XI', 550, 880);
INSERT INTO niveau (code_niveau, min_remuneration, max_remuneration) VALUES ('XII', 600, 960);
INSERT INTO niveau (code_niveau, min_remuneration, max_remuneration) VALUES ('XIII', 700, 1120);


INSERT INTO categorie_sp (code_categorie_sp) VALUES ('232a');
INSERT INTO categorie_sp (code_categorie_sp) VALUES ('343g');
INSERT INTO categorie_sp (code_categorie_sp) VALUES ('373c');
INSERT INTO categorie_sp (code_categorie_sp) VALUES ('373d');
INSERT INTO categorie_sp (code_categorie_sp) VALUES ('374d');
INSERT INTO categorie_sp (code_categorie_sp) VALUES ('376g');
INSERT INTO categorie_sp (code_categorie_sp) VALUES ('381b');
INSERT INTO categorie_sp (code_categorie_sp) VALUES ('461d');
INSERT INTO categorie_sp (code_categorie_sp) VALUES ('471a');
INSERT INTO categorie_sp (code_categorie_sp) VALUES ('542a');
INSERT INTO categorie_sp (code_categorie_sp) VALUES ('543d');
INSERT INTO categorie_sp (code_categorie_sp) VALUES ('543g');
INSERT INTO categorie_sp (code_categorie_sp) VALUES ('564b');


INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Agent d''entretien', 13, 1);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Agent de service', 13, 1);

INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Secrétaire administratif', 10, 2);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Assistant opérationnel A', 12, 2);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Assistant opérationnel B', 12, 3);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Assistant départemental A', 2, 3);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Assistant régional A', 12, 3);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Assistant opérationnel C', 4, 4);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Assistant départemental B', 4, 4);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Assistant de direction A', 4, 4);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Assistant régional B', 4, 5);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Assistant départemental C', 4, 6);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Assistant de direction B', 4, 7);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Assistant de direction C', 4, 8);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Assistant départementale D', 4, 7);

INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Médiateur foncier', 9, 3);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Conseiller foncier A', 6, 4);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Conseiller foncier B', 6, 5);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Conseiller foncier C', 6, 6);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Conseiller foncier D', 6, 7);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Conseiller foncier E', 6, 8);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Chargé de mission foncière', 7, 8);

INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Chargé d''études A', 9, 3);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Chargé d''études B', 7, 5);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Chargé d''études C', 7, 6);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Chargé d''études D', 7, 7);

INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau)
VALUES ('Chef de service départemental A/DDal A', 5, 8);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Chef de service régional A', 4, 8);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau)
VALUES ('Chef de service départemental B/DDal B', 4, 10);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Chef de service régional B', 4, 10);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Chef de service régional C', 4, 11);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau)
VALUES ('Chef de service départemental C/DDal C', 5, 11);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau)
VALUES ('Cadre de direction régionale A', 4, 11);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau)
VALUES ('Cadre de direction régionale B', 4, 12);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau)
VALUES ('Chef de service départemental D/DDal D', 5, 12);
--INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Directeur adjoint A', '', 12);
--INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Directeur adjoint B', '', 13);

INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Comptable A', 8, 3);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Comptable B', 3, 4);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Comptable C', 3, 7);

INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Attaché régional A', 11, 5);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Attaché régional B', 4, 7);
INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Attaché régional C', 4, 9);

--INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Directeur des opérations foncières', 1, );
--INSERT INTO emploi_ccn (intitule_emploi_ccn, id_categoriesp, id_niveau) VALUES ('Mandat social', 1, );


INSERT INTO indice VALUES (1, 6.57);


INSERT INTO convention (intitule_convention) VALUES ('Employé');
INSERT INTO convention (intitule_convention) VALUES ('Cadre dirigeant');
INSERT INTO convention (intitule_convention) VALUES ('Cadre');


INSERT INTO bulletin_modele_salaire (intitule_bulletin_modele_salaire) VALUES ('Non cadre');
INSERT INTO bulletin_modele_salaire (intitule_bulletin_modele_salaire) VALUES ('Cadre');
INSERT INTO bulletin_modele_salaire (intitule_bulletin_modele_salaire) VALUES ('Mandataire président');
INSERT INTO bulletin_modele_salaire (intitule_bulletin_modele_salaire) VALUES ('Mandataire directeur');
INSERT INTO bulletin_modele_salaire (intitule_bulletin_modele_salaire) VALUES ('Emploi jeunes');
INSERT INTO bulletin_modele_salaire (intitule_bulletin_modele_salaire) VALUES ('Agent d’entretien');
INSERT INTO bulletin_modele_salaire (intitule_bulletin_modele_salaire) VALUES ('Apprenti');
INSERT INTO bulletin_modele_salaire (intitule_bulletin_modele_salaire) VALUES ('Stagiaire');


INSERT INTO modalite_exercice_travail (intitule_modalite_exercice_travail) VALUES ('Temps plein');
INSERT INTO modalite_exercice_travail (intitule_modalite_exercice_travail) VALUES ('Temps partiel');
INSERT INTO modalite_exercice_travail (intitule_modalite_exercice_travail) VALUES ('Temps partiel thérapeutique');

INSERT INTO contrat_travail VALUES (1, TRUE, FALSE, TRUE, 'Titre', 'CONTRAT DE TRAVAIL');
INSERT INTO contrat_travail VALUES (2, TRUE, FALSE, FALSE, 'Désignation parties prenantes', 'Entre les soussignés :
@B@ La SAFER NOUVELLE AQUITAINE, @/B@ S.A. au capital de @A_COMPLETER@
dont le siège social est sis 16 avenue de Chavailles, 33 Brugres,
Représentée par : Monsieur Philippe TUZELET, agissant en qualité de Directeur général Délégué, ayant tout pouvoir à l''effet des présentes

                                                                                                                                                                       D''une part,
Et

@B@ @GENRE@ @PRENOM@ @NOM@ @/B@
Demeurant : @ADRESSE@
@COMPLEMENT_ADRESSE@
@CODE_POSTAL@ @COMMUNE@
Né(e) le : @DATE_NAISSANCE@ à @DEPARTEMENT_NAISSANCE@
De nationalité : @NATIONALITE@
Immatriculé au régime de Sécurité Sociale sous le n° @NUMERO_IMMATRICULATION@

                                                                                                                                                                       D''autre part,');
INSERT INTO contrat_travail VALUES (3, FALSE, FALSE, TRUE,'Préambule',
                                    'La société doit palier à l''absence de @A_COMPLETER@, occupant le poste de @A_COMPLETER@, suite @A_COMPLETER@. Il est donc procédé au recrutement de @GENRE@ @PRENOM@ @NOM@ pour le remplacement de @A_COMPLETER@ du @DATE_DE_DEBUT@ au @A_COMPLETER@.');
INSERT INTO contrat_travail VALUES (4, TRUE, TRUE, TRUE,'Engagement', 'La société engage par les présentes, à compter du @DATE_DE_DEBUT@ à 8h30, @PREFIXE_GENRE@ @PRENOM@ @NOM@, dans le cadre d''un @NATURE_CONTRAT@, en qualité de @EMPLOI_CCN@, sous réserve de résultats de la visite médicale d''embauche.

@PREFIXE_GENRE@ @PRENOM@ @NOM@ se déclare libre de tout engagement.

Le contrat de travail est régi par les dispositions de la Convention Collective Nationale des SAFER, cette mention n''ayant pas pour effet de contractualiser ces dispositions.
La société a déclaré préalablement son embauche à la mutualité Sociale Agricole de @ETABLISSEMENT@');
INSERT INTO contrat_travail VALUES (5, TRUE, TRUE, TRUE,'Attributions', '@PREFIXE_GENRE@ @PRENOM@ @NOM@ exercera l''emploi de @EMPLOI_CCN@, statut @STATUT@, au coefficient @COEFFICIENT@ de la Convention collective des SAFER.
A ce poste, sous l''autorité de @A_COMPLETER@, il sera notamment chargé :
@MISSIONS@
et de tous travaux liés au développement de l''activité.

Les missions décrites ci-dessus pourront évoluer et être modifiées par la Direction en fonction de l''évolution des besoins de l''entreprise.');
INSERT INTO contrat_travail VALUES (6, TRUE, TRUE, TRUE,'Période d''essai et préavis - Résiliation', 'Le contrat ne deviendra ferme qu''à l''issue d''une période d''essai de @DUREE_PERIODE_ESSAI@. Cette période devant correspondra à une période de travail effectif, elle sera suspendue en cas d''absence de @PREFIXE_GENRE@ @PRENOM@ @NOM@ pour quelque motif que ce soit.
Au cours de cette période, le contrat est résiliable selon les conditions suivantes :

- Délai de prévenance devant être observé par la Safer Nouvelle Aquitaine (Art. L. 1221-25) :
      - 24 heures : en deçà de 8 jours de présence
      - 48 heures : entre 8 jours et un mois de présence
      - 2 semaines : après un mois de présence
      - 1 mois : après trois mois de présence.

- Délai de prévenance devant être observé par @PREFIXE_GENRE@ @PRENOM@ @NOM@ (Art. L. 1221-26):
      - 48 heures en règle générale
      - 24 heures si présence inférieure à 8 jours de présence

La résiliation du contrat définitif sera régie par les dispositions légales ou conventionnelles en vigueur à la date de la rupture. A titre indicatif, il est précisé qu''à la date de signature du présent contrat, la durée du préavis conventionnel, sauf faute grave ou lourde, est de 3 mois pour le licenciement et 2 mois pour la démission pendant les 5 premières années, 4 mois pour le licenciement et 2 mois pour la démission après cinq ans de présence ou cinquante ans d''âge.');
INSERT INTO contrat_travail VALUES (7, TRUE, TRUE, TRUE,'Lieu de travail', '@PREFIXE_GENRE@ @PRENOM@ @NOM@ sera affecté(e) au Service Départemental de @ETABLISSEMENT@, basé, à la signature des présentes, @A_COMPLETER@.
Toutefois, il est expressément convenu entre les parties que toute modification du lieu d''établissement du @ETABLISSEMENT@ vers un des autres établissements de l''entreprise situés respectivement @A_COMPLETER@, sera considérée comme un simple changement des conditions de travail.
En conséquence, le refus de @PREFIXE_GENRE@ @PRENOM@ @NOM@ d''accepter une mutation dans un de ces établissements de l''entreprise, serait susceptible d''entraîner la rupture du présent contrat.');
INSERT INTO contrat_travail VALUES (8, FALSE, TRUE, TRUE,'Horaires de Travail', 'La durée mensuelle de travail est de @NOMBRE_HEURES_TRAVAILLEES@ heures réparties sur 5 jours du lundi au vendredi et repose sur les dispositions de l''accord d''entreprise portant sur l''aménagement du temps de travail signé le @A_COMPLETER@.

Il est expressément convenu entre les parties que les horaires de travail ainsi communiqués ne sont aucunement contractuels et ne constituent pas un élément essentiel du présent contrat. En conséquence, ils pourront être modifiés par l''entreprise, notamment en fonction de l''organisation de l''entreprise et des nécessités de service.');
INSERT INTO contrat_travail VALUES (9, TRUE, TRUE, TRUE,'Rémunération', '@PREFIXE_GENRE@ @PRENOM@ @NOM@ percevra un salaire brut de @REMUNERATION@ euros qui lui sera versé chaque mois. Cette rémunération sera calculée de la manière suivante :

- Indice de base : @COEFFICIENT@ points
x@INDICE_SALAIRE@ (valeur actuelle du point d''indice FN SAFER)

A titre informatif, s''ajouteront à cette rémunération :
- la prime de 8% prévue à l''article 43 de la convention collective
- en fonction des résultats de l''entreprise, les primes d''intéressement et de participation dans les conditions fixées par les accords d''entreprise signés les @A_COMPLETER@ et @A_COMPLETER@');
INSERT INTO contrat_travail VALUES (10, TRUE, TRUE, TRUE,'Régimes complémentaires', '@PREFIXE_GENRE@ @PRENOM@ @NOM@ sera affilié(e) à la CCPMA Prévoyance, à la caisse de Complémentaire CAMARCA (Caisse Mutuelle Autonome de Retraite Complémentaire Agricole AGRICA) @SI@ @AGIRC@=1 @ALORS@ et à la CRCCA(Caisse de Retraite Complémentaire des Cadres AGRICA) @/SI@ .
@Il_Elle@ s''engage d''autre part à adhérer au contrat de groupe obligatoire signé par la SAFER Nouvelle Aquitaine avec @A_COMPLETER@ (nom de la mutuelle) concernant l''assurance maladie complémentaire et dans le cas contraire à respecter les conditions de non adhésion prévue au dit contrat.');
INSERT INTO contrat_travail VALUES (11, FALSE, TRUE, TRUE,'Congés Payés',
                                    '@PREFIXE_GENRE@ @PRENOM@ @NOM@ bénéficiera des congés payés annuels selon les articles L. 3141-1 à L.3141-29 du Code du Travail et dans les conditions prévues par la convention Collective Nationale des SAFER.');
INSERT INTO contrat_travail VALUES (12, FALSE, TRUE, TRUE,'Obligations profesionnelles', '@PREFIXE_GENRE@ @PRENOM@ @NOM@ s''engage  à  observer toutes  les  instructions  qui  lui  seront  données, verbalement  ou  par écrit, et à faire  connaître sans délai, tout  changement  de  situation le concernant. @Il_Elle@ s''engage à observer, pendant l''exécution comme après la cessation du contrat, une discrétion professionnelle absolue concernant les faits ou les informations dont @il_elle@ aura eu connaissance dans l''exercice ou à l''occasion de ses fonctions. @Il_Elle@ s''engage  à ne  pas effectuer de  copies ni transmettre  à autrui les fichiers informatiques  qu'' @il_elle@ réalise ou dont @il_elle@ a communication dans le cadre de son travail.

@PREFIXE_GENRE@ @PRENOM@ @NOM@ ne pourra exercer sous quelque forme que ce soit une activité concurrente de celle de son employeur pendant l''exécution du présent contrat.');
INSERT INTO contrat_travail VALUES (13, FALSE, TRUE, TRUE,'Restitution',
                                    'Il est rappelé à @PREFIXE_GENRE@ @PRENOM@ @NOM@ que tous documents mis à sa disposition (bases de données, cartographies, fichiers informatiques, ...) ou établis par ses soins dans le cadre de son activité, ainsi que tous matériels (logiciels, véhicule,  ordinateur portable, téléphone mobile, clés des locaux, ...) demeurent la propriété exclusive de l’entreprise et devront être restitués à la cessation du présent contrat de travail pour quel que motif que ce soit.');
INSERT INTO contrat_travail VALUES (14, TRUE, FALSE, TRUE,'Signature', 'Fait en deux exemplaires, à A COMPLETER le @DATE_COURANTE@.

Signatures précédées de la mention manuscrite ''Lu et approuvé''


@PREFIXE_GENRE@ @PRENOM@ @NOM@                                                            				         Philippe TUZELET
L''employé                                                                     				     Directeur Général Délégué');

INSERT INTO lettre_embauche
VALUES (1, TRUE, 'Coordonnées', '@PREFIXE_GENRE@ @PRENOM@ @NOM@ @ADRESSE@ @CODE_POSTAL@ @VILLE@');
INSERT INTO lettre_embauche VALUES (2, TRUE, 'Lieu et date', 'Bruges, le @DATE_COURANTE@');
INSERT INTO lettre_embauche VALUES (4, TRUE, 'Objet', ': Promesse d''embauche');
INSERT INTO lettre_embauche VALUES (5, TRUE, 'Civilité', '@GENRE@,');
INSERT INTO lettre_embauche VALUES (6, TRUE, 'Rappel', 'Suite à nos différents entretiens, nous avons le plaisir de vous confirmer votre engagement sous @CONTRAT@ au sein de notre société dans les conditions suivantes :


-	Date d''entrée : @DATE_DE_DEBUT@ au plus tard
-	Emploi : @EMPLOI@ au sein du Service @DEPARTEMENT@
-	Statut : @STATUT@
-	Horaire mensuel : @HORAIRE@ heures
-	Coefficient : @COEFFICIENT@
-	Rémunération brute mensuelle : @REMUNERATION@ €


Les conditions générales du contrat de travail qui vous sera proposé, confirmant notre lettre d''intention sont celles de la convention collective nationale des SAFER.');

INSERT INTO lettre_embauche VALUES (7, TRUE, 'Demande retour', 'Pour la bonne tenue de votre dossier, vous voudrez bien nous retourner, avant le @DATE_PRESCRITE@ un exemplaire de la présente revêtu de votre signature précédée de la mention manuscrite « lu et approuvé ». D''
-	Copie de votre carte d''identité, recto/verso
-	Copie de l''attestation de droits délivrée par votre caisse d''assurance maladie.
');

INSERT INTO lettre_embauche VALUES (8, TRUE, 'Fixer rendez-vous',
                                    'Nous reprendrons contact avec vous dans les meilleurs délais afin de fixer un rendez-vous pour finaliser votre engagement.');
INSERT INTO lettre_embauche VALUES (9, TRUE, 'Formule politesse',
                                    'Dans l’attente, nous vous prions de croire, @PREFIXE_GENRE@, à l''expression de nos meilleurs sentiments.');
INSERT INTO lettre_embauche VALUES (10, TRUE, 'Signature', 'Philippe Tuzelet
Directeur Général
');
